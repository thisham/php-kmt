<?php

define('BASIS_URL', 'http://localhost:82/project/maintenance-app/publik');

// Pangkalan Data
define('NAMA_PD', 'basis_data');
define('NAMA_UN', 'root');
define('NAMA_KS', '');
define('NAMA_NH', 'localhost');
