<div class="container">
	<div class="jumbotron mt-4">
		<h1 class="display-4">App Kamu Berhasil Terinstal!</h1>
		<p class="lead"><?php echo $data['nama']; ?>, kamu bisa lihat view ini di app/tampilan/beranda/index.php</p>
		<hr class="my-4">
		<p>Kontroler dari laman ini ada di app/kontroler/beranda.php. Modelnya ada di app/model/model_pengguna.php.</p>
		<a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
	</div>
</div>