<script src="<?php echo BASIS_URL; ?>/js/bootstrap.js"></script>
<script src="<?php echo BASIS_URL; ?>/js/jquery-3.4.1.slim.min.js"></script>
<script src="<?php echo BASIS_URL; ?>/js/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="<?php echo BASIS_URL; ?>/js/bootstrap.min.js"></script>
<script src="<?php echo BASIS_URL; ?>/js/skrip-crud.js"></script>
</body>
</html>