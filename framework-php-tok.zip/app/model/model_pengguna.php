<?php

/**
 * 
 */
class model_pengguna extends Kontroler
{
	private $nama = "waw";

	public function getPengguna()
	{
		return $this->nama;
	}
}