<?php 
// App.php dan Kontroller.php adl file utama pembentuk MVC.
require_once 'inti/App.php'; // Huruf kapital yang ditulis pada nama fle utk menandakan kelas.
require_once 'inti/Database.php';
require_once 'inti/Kontroler.php';
require_once 'inti/Flasher.php';
require_once 'konfigurasi/konfigurasi.php';
?>